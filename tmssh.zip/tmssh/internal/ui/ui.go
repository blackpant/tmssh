// Package ui pilote fzf : liste des hosts, multi-select, gestion des tags.
package ui

import (
	"bufio"
	"fmt"
	"io"
	"os"
	"os/exec"
	"strings"

	"github.com/you/tmssh/internal/config"
)

// Icônes Nerd Fonts par tag "type" (personnalisable plus tard via la config).
var tagIcons = map[string]string{
	"prod":    "",
	"staging": "",
	"web":     "",
	"db":      "",
}

const defaultIcon = ""

// PrintList écrit la liste des hosts au format consommé par fzf :
//
//	<name>\t<icône> <name>  <user>@<hostname>  [tag1,tag2]
//
// La 1re colonne (cachée par --with-nth=2..) sert de clé stable pour {+1}.
func PrintList(cfg *config.Config, w io.Writer) error {
	for _, h := range cfg.Hosts {
		target := h.HostName
		if h.User != "" {
			target = h.User + "@" + target
		}
		tags := ""
		if len(h.Tags) > 0 {
			tags = "[" + strings.Join(h.Tags, ",") + "]"
		}
		fmt.Fprintf(w, "%s\t%s %-20s %-30s %s\n",
			h.Name, iconFor(h), h.Name, target, tags)
	}
	return nil
}

func iconFor(h config.Host) string {
	for _, t := range h.Tags {
		if ic, ok := tagIcons[t]; ok {
			return ic
		}
	}
	return defaultIcon
}

// Run lance l'UI fzf principale.
//
// Bindings :
//   - Tab      : multi-sélection
//   - Enter    : tmssh connect <hosts>
//   - ctrl-a   : tmssh tag add <hosts>  puis reload
//   - ctrl-d   : tmssh tag rm  <hosts>  puis reload
//   - ctrl-h   : affiche l'historique en preview
func Run(cfg *config.Config) error {
	self, err := os.Executable()
	if err != nil {
		return err
	}

	args := []string{
		"--multi",
		"--ansi",
		"--delimiter=\t",
		"--with-nth=2..", // cache la colonne clé
		"--prompt=ssh ❯ ",
		"--header=Tab: sélection ▪ Enter: connect ▪ C-a: +tag ▪ C-d: -tag ▪ C-h: historique",
		"--preview=" + self + " history",
		"--preview-window=hidden",
		"--bind=ctrl-h:toggle-preview",
		fmt.Sprintf("--bind=ctrl-a:execute(%s tag add {+1})+reload(%s list)", self, self),
		fmt.Sprintf("--bind=ctrl-d:execute(%s tag rm {+1})+reload(%s list)", self, self),
	}

	cmd := exec.Command("fzf", args...)
	cmd.Stderr = os.Stderr

	stdin, err := cmd.StdinPipe()
	if err != nil {
		return err
	}
	var out strings.Builder
	cmd.Stdout = &out

	if err := cmd.Start(); err != nil {
		return fmt.Errorf("fzf introuvable ? %w", err)
	}
	if err := PrintList(cfg, stdin); err != nil {
		return err
	}
	stdin.Close()

	if err := cmd.Wait(); err != nil {
		// Code 130 = annulation (Esc / ctrl-c) : pas une erreur.
		if ee, ok := err.(*exec.ExitError); ok && ee.ExitCode() == 130 {
			return nil
		}
		return err
	}

	// Récupère la clé (colonne 1) de chaque ligne sélectionnée.
	var names []string
	sc := bufio.NewScanner(strings.NewReader(out.String()))
	for sc.Scan() {
		if name, _, ok := strings.Cut(sc.Text(), "\t"); ok {
			names = append(names, name)
		}
	}
	if len(names) == 0 {
		return nil
	}

	// Se relance en sous-commande pour bénéficier du même code chemin
	// que le binding Enter documenté.
	connect := exec.Command(self, append([]string{"connect"}, names...)...)
	connect.Stdout, connect.Stderr = os.Stdout, os.Stderr
	return connect.Run()
}

// TagAdd demande un tag (fzf en mode saisie libre + suggestions) et
// l'applique aux hosts donnés.
func TagAdd(cfg *config.Config, hosts []string) error {
	tag, err := pickTag("Ajouter un tag ❯ ", cfg.AllTags())
	if err != nil || tag == "" {
		return err
	}
	return cfg.AddTag(tag, hosts)
}

// TagRemove propose les tags communs aux hosts sélectionnés et retire
// celui choisi.
func TagRemove(cfg *config.Config, hosts []string) error {
	common := cfg.CommonTags(hosts)
	if len(common) == 0 {
		fmt.Fprintln(os.Stderr, "aucun tag commun à retirer")
		return nil
	}
	tag, err := pickTag("Retirer un tag ❯ ", common)
	if err != nil || tag == "" {
		return err
	}
	return cfg.RemoveTag(tag, hosts)
}

// pickTag ouvre un fzf secondaire : suggestions + saisie libre (--print-query).
func pickTag(prompt string, suggestions []string) (string, error) {
	cmd := exec.Command("fzf",
		"--prompt="+prompt,
		"--print-query", // permet de créer un tag inexistant
		"--height=~40%",
	)
	cmd.Stdin = strings.NewReader(strings.Join(suggestions, "\n"))
	cmd.Stderr = os.Stderr

	out, err := cmd.Output()
	if err != nil {
		if ee, ok := err.(*exec.ExitError); ok && (ee.ExitCode() == 130 || ee.ExitCode() == 1) {
			// Annulé, ou aucune correspondance : avec --print-query la
			// requête tapée reste utilisable en 1re ligne.
			lines := strings.Split(strings.TrimRight(string(out)+string(ee.Stderr), "\n"), "\n")
			if ee.ExitCode() == 1 && lines[0] != "" {
				return strings.TrimSpace(lines[0]), nil
			}
			return "", nil
		}
		return "", err
	}

	// Sortie : ligne 1 = query, ligne 2 = sélection (si match).
	lines := strings.Split(strings.TrimRight(string(out), "\n"), "\n")
	if len(lines) >= 2 && lines[1] != "" {
		return strings.TrimSpace(lines[1]), nil
	}
	return strings.TrimSpace(lines[0]), nil
}
